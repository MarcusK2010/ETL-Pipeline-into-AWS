import json
import pandas as pd
import requests
from datetime import datetime
import pytz
from pytz import timezone
import marcus_keys

def lambda_handler(event, context):
    
    
    def get_weather_data(cities):
        api_key = marcus_keys.open_weather_key
        tz = pytz.timezone("Europe/Berlin")
        now = datetime.now().astimezone(tz)
    
        weather_data = {"city_name": [],
                        "country_code": [],
                        "date_time": [],
                        "temperature": [],
                        "wind_speed": [],
                        "humidity": [],
                        "outlook": []}
    
        for city in cities:
            url = f"https://api.openweathermap.org/data/2.5/forecast?q={city}&appid={api_key}&units=metric"
            weather = requests.get(url)
            weather_json = weather.json()
            
            for i in weather_json["list"]:
                weather_data["city_name"].append(weather_json["city"]["name"])
                weather_data["country_code"].append(weather_json["city"]["country"])
                weather_data["date_time"].append(i["dt_txt"])
                weather_data["temperature"].append(i["main"]["temp"])
                weather_data["wind_speed"].append(i["wind"]["speed"])
                weather_data["humidity"].append(i["main"]["humidity"])
                weather_data["outlook"].append(i["weather"][0]["description"])
                weather_data["data_collection_from"] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
        return pd.DataFrame(weather_data)
        
    
    def process_weather_data(weather_data_raw_df):
        weather_data_raw_df["data_collection_from"] = pd.to_datetime(weather_data_raw_df["data_collection_from"])
        weather_data_raw_df["date_time"] = pd.to_datetime(weather_data_raw_df["date_time"])
        
        return weather_data_raw_df
        
    
    cities = ["Berlin", "Hamburg", "Stuttgart", "Duesseldorf"]
    
    weather_data_raw_df = pd.DataFrame(get_weather_data(cities))
    
    weather_data_df = process_weather_data(weather_data_raw_df)
    
    schema="aws_p5_gans_database"
    host="wbs-cs-p5-db.cjdcbdhnueky.eu-north-1.rds.amazonaws.com"
    user="mkadmin"
    password=marcus_keys.aws_rds_key
    port=3306
    con = f'mysql+pymysql://{user}:{password}@{host}:{port}/{schema}'
    
    weather_data_df.to_sql('weather_table', 
                            if_exists='append', 
                            con=con, 
                            index=False)

    
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
