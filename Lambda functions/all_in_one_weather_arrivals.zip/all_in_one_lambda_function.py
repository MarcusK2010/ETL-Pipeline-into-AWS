import json
import pandas as pd
import requests
from datetime import datetime
import pytz
from pytz import timezone
import marcus_keys

def lambda_handler(event, context):
    
    
    def get_weather_data(cities):
        api_key = marcus_keys.open_weather_key
        tz = pytz.timezone("Europe/Berlin")
        now = datetime.now().astimezone(tz)
    
        weather_data = {"city_name": [],
                        "country_code": [],
                        "date_time": [],
                        "temperature": [],
                        "wind_speed": [],
                        "humidity": [],
                        "outlook": []}
    
        for city in cities:
            url = f"https://api.openweathermap.org/data/2.5/forecast?q={city}&appid={api_key}&units=metric"
            weather = requests.get(url)
            weather_json = weather.json()
            
            for i in weather_json["list"]:
                weather_data["city_name"].append(weather_json["city"]["name"])
                weather_data["country_code"].append(weather_json["city"]["country"])
                weather_data["date_time"].append(i["dt_txt"])
                weather_data["temperature"].append(i["main"]["temp"])
                weather_data["wind_speed"].append(i["wind"]["speed"])
                weather_data["humidity"].append(i["main"]["humidity"])
                weather_data["outlook"].append(i["weather"][0]["description"])
                weather_data["data_collection_from"] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
        return pd.DataFrame(weather_data)
        
    
    def process_weather_data(weather_data_raw_df):
        weather_data_raw_df["data_collection_from"] = pd.to_datetime(weather_data_raw_df["data_collection_from"])
        weather_data_raw_df["date_time"] = pd.to_datetime(weather_data_raw_df["date_time"])
        
        return weather_data_raw_df
        
    
    def get_arrivals_data(iata_lst):
        api_key = marcus_keys.rapid_api_key_2
        tz = pytz.timezone("Europe/Berlin")
        times = [["00:00","11:59"],["12:00","23:59"]]
        now = datetime.now().astimezone(tz)
        today = datetime.now().astimezone(timezone("Europe/Berlin")).date()
        tomorrow = (today + timedelta(days=1))
    
        new_columns = {
            "number":"flight_number",
            "movement.airport.icao":"from_icao",
            "movement.airport.iata":"from_iata",
            "movement.revisedTime.local":"arrival_time",
            "airline.name":"airline",
            "movement.airport.name":"from_city",
            "movement.terminal":"arrival_terminal"
        }
    
        arr_lst_for_df = []
    
        for iata in iata_lst:
            for time in times:
                url = f"https://aerodatabox.p.rapidapi.com/flights/airports/iata/{iata}/{tomorrow}T{time[0]}/{tomorrow}T{time[1]}"
    
                querystring = {"direction":"Arrival"}
    
                headers = {
                    "X-RapidAPI-Key": api_key,
                    "X-RapidAPI-Host": "aerodatabox.p.rapidapi.com"
                }
    
            response = requests.get(url, headers=headers, params=querystring)
            print(response.status_code)
    
            arr_json = response.json()
    
            df = pd.json_normalize(arr_json["arrivals"])[["number", "movement.revisedTime.local", "movement.airport.icao", "movement.airport.iata", "movement.airport.name", "movement.terminal", "airline.name"]]
            data_df = df.rename(columns=new_columns)
            data_df["airport"] = iata
            data_df["data_collection_from"] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
            arr_lst_for_df.append(data_df)
    
        return pd.concat(arr_lst_for_df, ignore_index=True)
        
    
    def process_arrivals_data(arrivals_data_raw_df):
        arrivals_data_raw_df.rename(columns={"airport":"city_id"}, inplace=True)
        arrivals_data_raw_df = arrivals_data_raw_df[["city_id", "flight_number", "arrival_time", "from_icao", "from_iata", "from_city", "arrival_terminal", "airline", "data_collection_from" ]]
        
        for i in range(0, len(arrivals_data_raw_df["city_id"])):
            if arrivals_data_raw_df.loc[i, "city_id"] == "BER":
                arrivals_data_raw_df.loc[i, "city_id"] = "Q64"
            elif arrivals_data_raw_df.loc[i, "city_id"] == "HAM":
                arrivals_data_raw_df.loc[i, "city_id"] = "Q1055"
            elif arrivals_data_raw_df.loc[i, "city_id"] == "STR":
                arrivals_data_raw_df.loc[i, "city_id"] = "Q1022"
            else:
                arrivals_data_raw_df.loc[i, "city_id"] = "Q1718"
                
        arrivals_data_raw_df["data_collection_from"] = pd.to_datetime(arrivals_data_raw_df["data_collection_from"])
        arrivals_data_raw_df["arrival_time"] = pd.to_datetime(arrivals_data_raw_df["arrival_time"])
        
        return arrivals_data_raw_df
        
        
    cities = ["Berlin", "Hamburg", "Stuttgart", "Duesseldorf"]
    
    weather_data_raw_df = pd.DataFrame(get_weather_data(cities))
    
    weather_data_df = process_weather_data(weather_data_raw_df)
    
    schema="aws_p5_gans_database"
    host="wbs-cs-p5-db.cjdcbdhnueky.eu-north-1.rds.amazonaws.com"
    user="mkadmin"
    password=marcus_keys.aws_rds_key
    port=3306
    con = f'mysql+pymysql://{user}:{password}@{host}:{port}/{schema}'
    
    weather_data_df.to_sql('weather_table', 
                            if_exists='append', 
                            con=con, 
                            index=False)
                            
    iata_lst = ['BER', 'HAM', 'STR', 'DUS']
    
    arrivals_data_raw_df = get_arrivals_data(iata_lst)
    
    arrivals_data_df = process_arrivals_data(arrivals_data_raw_df)
    
    schema="aws_p5_gans_database"
    host="wbs-cs-p5-db.cjdcbdhnueky.eu-north-1.rds.amazonaws.com"
    user="mkadmin"
    password=marcus_keys.aws_rds_key
    port=3306
    con = f'mysql+pymysql://{user}:{password}@{host}:{port}/{schema}'
    
    arrivals_data_df.to_sql('arrivals_table', 
                            if_exists='append', 
                            con=con, 
                            index=False)
    
    
    return {
        'statusCode': 200,
        'body': json.dumps('All went smoothly!')
    }
