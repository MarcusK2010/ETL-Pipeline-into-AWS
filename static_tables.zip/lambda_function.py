import json
import pandas as pd
import sqlalchemy
import marcus_keys

def lambda_handler(event, context):
    
    
    iata_lst = ['BER', 'HAM', 'STR', 'DUS']
    city_lst = ["Berlin", "Hamburg", "Stuttgart", "Duesseldorf"]
    country_lst = ["DE", "DE", "DE", "DE"]
    q_id_lst = ["Q64", "Q1055", "Q1022", "Q1718"]
    airport_name_lst = ["Berlin-Brandenburg", "Hamburg", "Stuttgart", "Düsseldorf"]
    
    cities_df = pd.DataFrame({"city_id": q_id_lst, "city_name": city_lst, "country_code": country_lst})
    city_airport_df = pd.DataFrame({"city_id":q_id_lst, "iata_code":iata_lst})
    airports_df = pd.DataFrame({"iata_code":iata_lst, "airport_name":airport_name_lst})
    
    schema="aws_p5_gans_database"
    host="wbs-cs-p5-db.cjdcbdhnueky.eu-north-1.rds.amazonaws.com"
    user="mkadmin"
    password=marcus_keys.aws_rds_key
    port=3306
    con = f'mysql+pymysql://{user}:{password}@{host}:{port}/{schema}'
    
    cities_df.to_sql('city_table', if_exists='append', con=con, index=False)
    airports_df.to_sql('airport_table', if_exists='append', con=con, index=False)
    city_airport_df.to_sql('city_airport_table', if_exists='append', con=con, index=False)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
